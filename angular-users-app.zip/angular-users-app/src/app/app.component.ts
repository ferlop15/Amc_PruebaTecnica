// app.component.ts
import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';
import { User } from './user.model';
import { RouterOutlet } from "@angular/router";
import { FormsModule } from '@angular/forms'; 
import { DatePipe, CommonModule } from '@angular/common'; 

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  imports: [
    RouterOutlet, 
    FormsModule, 
    DatePipe, 
    CommonModule
  ]
})
export class AppComponent implements OnInit {
  title = 'Consulta de Usuarios CRUD';
  users: User[] = [];
  searchTerm: string = ''; // Campo para la búsqueda
  showTable: boolean = false;
  
  // Objeto para manejar la creación/edición de un usuario
  currentUser: User = this.getEmptyUser();
  isEditing: boolean = false;
  showForm: boolean = false; // Controla la visibilidad del formulario

  constructor(private userService: UserService) { }

  ngOnInit(): void {
    this.getUsers(); 
  }

  // 🔑 FUNCIÓN AUXILIAR AÑADIDA
  /**
   * Asegura que una cadena de fecha se formatee a 'YYYY-MM-DD', 
   * el único formato aceptado por input type="date".
   */
  private formatToDateInput(dateString: string): string {
    if (!dateString) return '';
    
    // Intenta crear un objeto Date a partir de la cadena de la API (ej: "2024-11-25T00:00:00Z")
    const date = new Date(dateString);
    
    if (isNaN(date.getTime())) return ''; // Si es inválida, devuelve vacío

    // Formatea la fecha como 'YYYY-MM-DD'
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    
    return `${year}-${month}-${day}`;
  }


  getEmptyUser(): User {
    return {
      usuId: 0,
      nombre: '',
      apellido: '',
      // Inicializa la fecha para el input type="date"
      fechaContratacion: new Date().toISOString().split('T')[0],
      cargo: '',
      salario: '',
      departamento: ''
    };
  }

  /**
   * Carga los usuarios (con o sin término de búsqueda).
   */
  getUsers(): void {
    this.userService.getUsers(this.searchTerm).subscribe({
      next: (data) => {
        // 🔑 CAMBIO: Mapear la data y usar la función de formato para la tabla
        this.users = data.map(user => ({
            ...user,
            fechaContratacion: this.formatToDateInput(user.fechaContratacion)
        }));
        this.showTable = true;
      },
      error: (e) => {
        console.error('Error al obtener usuarios', e);
        alert('Error al cargar los usuarios.');
      }
    });
  }

  // Abre el formulario para crear un nuevo usuario
  openCreateForm(): void {
    this.currentUser = this.getEmptyUser(); // Reinicia el formulario
    this.isEditing = false;
    this.showForm = true;
  }

  // Abre el formulario para editar un usuario existente
  openEditForm(user: User): void {
    // 🔑 CAMBIO: Clonar el objeto y usar la función de formato para el formulario
    this.currentUser = { 
        ...user,
        fechaContratacion: this.formatToDateInput(user.fechaContratacion)
    }; 
    this.isEditing = true;
    this.showForm = true;
  }

  // Guarda o actualiza el usuario
  saveUser(): void {
    if (this.isEditing) {
      // Modificar (Update)
      this.userService.updateUser(this.currentUser.usuId, this.currentUser).subscribe({
        next: () => {
          alert('Usuario actualizado con éxito.');
          this.getUsers(); // Recargar la lista
          this.showForm = false;
        },
        error: (e) => console.error('Error al actualizar', e)
      });
    } else {
      // Crear (Create)
      this.userService.createUser(this.currentUser).subscribe({
        next: () => {
          alert('Usuario creado con éxito.');
          this.getUsers(); // Recargar la lista
          this.showForm = false;
        },
        error: (e) => console.error('Error al crear', e)
      });
    }
  }

  // Elimina un usuario
  deleteUser(id: number): void {
    if (confirm(`¿Está seguro de que desea eliminar al usuario con ID ${id}?`)) {
      this.userService.deleteUser(id).subscribe({
        next: () => {
          alert('Usuario eliminado con éxito.');
          this.getUsers(); // Recargar la lista
        },
        error: (e) => console.error('Error al eliminar', e)
      });
    }
  }

  // Cierra el formulario
  cancelForm(): void {
    this.showForm = false;
    this.currentUser = this.getEmptyUser();
  }
}