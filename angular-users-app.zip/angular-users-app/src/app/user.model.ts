// user.model.ts
export interface User {
  usuId: number;
  nombre: string;
  apellido: string;
  fechaContratacion: string; 
  cargo: string;
  salario: string;
  departamento: string;
}